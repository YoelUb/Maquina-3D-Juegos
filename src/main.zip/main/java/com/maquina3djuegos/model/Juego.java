package com.maquina3djuegos.model;

public interface Juego {

    public void iniciarJuego();

}
