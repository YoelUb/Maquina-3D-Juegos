package com.maquina3djuegos.model.caballo;

import com.maquina3djuegos.model.Juego;

public class Caballo implements Juego {


    @Override
    public void iniciarJuego() {
        // Vacío para cumplir la interfaz
    }

}
