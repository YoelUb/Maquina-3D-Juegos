package com.maquina3djuegos.controller;

import com.maquina3djuegos.model.reinas.ReinasSolver;
import com.maquina3djuegos.controller.dto.JuegoResponse;
import com.maquina3djuegos.controller.dto.TableroMovimiento;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/nreinas")
public class JuegosController {

    @PostMapping("/jugar")
    public JuegoResponse jugar(@RequestBody TableroMovimiento mov) {
        int[][] tablero2D = mov.getTablero();
        int n = tablero2D.length;

        // 1) Creamos solver vacio de tamaño n
        ReinasSolver solver = new ReinasSolver(n);

        // 2) Convertimos el tablero 2D en estado 1D: tablero[i] = columna o -1
        int[] estado1D = new int[n];
        for (int fila = 0; fila < n; fila++) {
            estado1D[fila] = -1;
            for (int col = 0; col < n; col++) {
                if (tablero2D[fila][col] == 1) {
                    estado1D[fila] = col;
                    break;
                }
            }
        }

        // 3) Cargamos ese estado en el solver
        solver.cargarTablero(estado1D);

        // 4) Aplicamos la jugada
        boolean valido = solver.jugar(mov.getFila(), mov.getColumna());

        // 5) Reconstruimos el nuevo tablero 2D desde solver.getTablero()
        int[] plano = solver.getTablero();
        int[][] nuevoEstado = new int[n][n];
        for (int fila = 0; fila < n; fila++) {
            if (plano[fila] >= 0) {
                nuevoEstado[fila][plano[fila]] = 1;
            }
        }

        // 6) Devolvemos la respuesta completa
        return new JuegoResponse(
                valido,
                solver.getPuntuacion(),
                solver.getErrores(),
                solver.haGanado(),
                nuevoEstado
        );
    }

    @GetMapping("/reset")
    public String reset() {
        return "Ok";
    }
}
