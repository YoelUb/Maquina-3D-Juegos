package com.maquina3djuegos.adapter;

public interface JuegoVisualAdapter {
    String obtenerTablero();
}