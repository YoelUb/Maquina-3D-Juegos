package com.maquina3djuegos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ArcadeApplication {
    public static void main(String[] args) {
        SpringApplication.run(ArcadeApplication.class, args);
    }
}
